'use strict';
import expression from './expression';
module.exports = function(server){
    expression(server)
}