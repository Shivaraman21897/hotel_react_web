export default {
    GET_TOKEN: 'Get Token',
    USER_TOKEN: 'Get user token',
    REFRESH_TOKEN: 'Get refresh token',
    FORGET_PASSWORD: 'Get Forget password',
    VERIFY_FORGET_OTP: 'Verify Forget Otp',
    RESET_PASSWORD: 'Reset Password',
    CHANGE_PASSWORD: 'Change Password'
}