export default {
    GET_COUNTRY_LIST: 'Get Country List',
    GET_COUNTRY_DETAILS: 'Get Country Details',
    SAVE_COUNTRY: 'Save Country',
    UPDATE_COUNTRY: 'Update Country',
    DELETE_COUNTRY: 'Delete Country'
}