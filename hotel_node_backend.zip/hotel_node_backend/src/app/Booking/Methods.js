export default {
  GET_BOOKING_LIST: "Get Booking List",
  GET_BOOKING_DETAILS: "Get Booking Details",
  SAVE_BOOKING: "Save Booking",
  UPDATE_BOOKING: "Update Booking",
  DELETE_BOOKING: "Delete Booking",
};
