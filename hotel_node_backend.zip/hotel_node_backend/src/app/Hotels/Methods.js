export default {
    GET_HOTELS_LIST: 'Get Hotels List',
    GET_HOTELS_DETAILS: 'Get Hotels Details',
    SAVE_HOTELS: 'Save Hotels',
    UPDATE_HOTELS: 'Update Hotels',
    DELETE_HOTELS: 'Delete Hotels'
}