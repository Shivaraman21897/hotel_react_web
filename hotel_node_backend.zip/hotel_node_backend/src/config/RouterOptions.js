const RouterOptions = {
    caseSensitive: true,
    mergeParams: false,
    strict: true,
}

export default RouterOptions;